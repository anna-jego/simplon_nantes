# cifar10-mosaic

Generate a  random cifar10 picture created with a mosaic of pictures from the same class
> 1. run first /datasets/get_datasets.sh
> 2. then the Jupyter notebook cifar10_mosaic.ipynb

![horse-mosaic](./horse-mosaic.png?raw=true "horse-mosaic")
